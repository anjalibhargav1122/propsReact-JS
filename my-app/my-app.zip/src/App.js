import React from 'react'
import Home from './test/Home'
import About from './test/About'
import Contact from './test/Contact'
import {BrowserRouter, Routes, Route} from 'react-router-dom'

const App = () => {
  return (
    <div>
      <BrowserRouter>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/contact' element={<Contact/>}/>
              </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App