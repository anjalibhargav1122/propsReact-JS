import React, { useEffect, useState } from 'react'
import Header from './Header'

const Contact = ({e}) => {
    const [c, setc] = useState();

    useEffect(()=>{
        setc(1)
    },[])

  return (
    <div>
        <Header/>

<p>{e} Contact Page.</p>
<div style={{display: c ==1 ?'block':'none'}}>
<form>
    <input type='text'/>
    <input type='number'/>
    <input type='email'/>
    <input type='password'/>
    <button className='btn btn-success' onClick={()=>{setc(2)}}>Login</button>
</form>



</div>



<div style={{display: c ==2 ?'block':'none'}}>

<form>
  
    <input type='email'/>
    <input type='password'/>
    <button className='btn btn-danger' onClick={()=>{setc(1)}}>Sign in</button>
</form>
</div>









    </div>
  )
}

export default Contact