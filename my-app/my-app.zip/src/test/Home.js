import React from 'react'
import Header from './Header'
import About from './About'

const Home = ({c}) => {
  return (
    <div>
      <p>{c} Home Page.</p>
        <Header/>
        <About d ={c}/>
    </div>
  )
}

export default Home